#include <iostream>
#include <cstring>
#include <stdexcept>
#include <fstream>
#include <limits> // for numeric_limits
using namespace std;

class Flight {
protected:
    string flightNumber;
    string destination;
    int farePerTicket;

public:
    Flight(string fn, string d, int fpt) : flightNumber(fn), destination(d), farePerTicket(fpt) {}

    virtual void display(int index) const = 0;

    string getFlightNumber() const {
        return flightNumber;
    }

    string getDestination() const {
        return destination;
    }

    int getFarePerTicket() const {
        return farePerTicket;
    }
};

class Airplane : public Flight {
public:
    Airplane(string fn, string d, int fpt) : Flight(fn, d, fpt) {}

    void display(int index) const {
        cout << index << ". Flight Number: " << flightNumber << "\tDestination: " << destination << "\tFare per ticket: PKR" << farePerTicket << endl;
    }
};

class CustomerInvoice {
private:
    char customerName[20];
    Flight* bookedFlight;
    int flightNumber;
    int ticketCount;
    int totalFare;
    string contactNumber;
    string cnic;

public:
    CustomerInvoice() {}

    CustomerInvoice(const char name[20], Flight* flight, int flightno, int count, int fare, string no, string ic) {
        bookedFlight = flight;
        flightNumber = flightno;
        ticketCount = count;
        totalFare = fare;
        contactNumber = no;
        cnic = ic;
        strcpy(customerName, name);
    }

    void display() const {
        cout << "                                  =================================================\n";
        cout << "                                  ||               CUSTOMER INVOICE              ||\n";
        cout << "                                  =================================================\n";
        cout << "                               | Customer Name                  | " << customerName << endl;
        cout << "                               | CNIC Number                    | " << cnic << endl;
        cout << "                               | Contact Number                 | " << contactNumber << endl;
        cout << "                               | Flight Number                  | " << bookedFlight->getFlightNumber() << endl;
        cout << "                               | Flight Code                    | " << flightNumber << endl;
        cout << "                               | No of Tickets                  | " << ticketCount << endl;
        cout << "                               | Fare per Ticket                | PKR" << bookedFlight->getFarePerTicket() << endl;
        cout << "\n                             | Total Fare Amount               | PKR" << totalFare << endl;

        try {
            ofstream file("flight.txt", ios::app);
            if (!file.is_open()) {
                throw runtime_error("Unable to open file for writing.");
            } else {
                file << "Customer Name      : " << customerName << "\n";
                file << "CNIC Number        : " << cnic << "\n";
                file << "Contact Number     : " << contactNumber << "\n";
                file << "Flight Number      : " << bookedFlight->getFlightNumber() << "\n";
                file << "Flight Code        : " << flightNumber << "\n";
                file << "No of Tickets      : " << ticketCount << "\n";
                file << "Fare per Ticket    : PKR" << bookedFlight->getFarePerTicket() << "\n";
                file << "Total Fare Amount  : PKR" << totalFare << "\n\n";
                file.close();
            }
        } catch (const exception &e) {
            cerr << "Error: " << e.what() << "\n";
        }
    }

    void ReadFile() {
        try {
            ifstream file("flight.txt");
            if (!file.is_open()) {
                throw runtime_error("Unable to open file for reading.");
            } else {
                cout << "                                  =====================================================\n";
                cout << "                                  ||                  CUSTOMER RECORD                ||\n";
                cout << "                                  =====================================================\n";
                string line;
                while (getline(file, line)) {
                    cout << line << endl;
                }
                file.close();
            }
        } catch (const exception &e) {
            cerr << "Error: " << e.what() << "\n";
        }
    }
};

class TotalBill {
private:
    int totalFare;

public:
    TotalBill() : totalFare(0) {}

    void addFare(int fare) {
        totalFare += fare;
    }

    void displayTotal() const {
        cout << "                                     =================================================\n";
        cout << "                                     ||      TOTAL PAYMENT FOR ALL BOOKED FLIGHTS   ||\n";
        cout << "                                      =================================================\n";
        cout << endl;
        cout << "                     |TOTAL PAYMENT OF A DAY  :           | " << "PKR " << totalFare << endl;
        cout << endl;
        cout << endl;
    }
};

class AirlineReservationSystem {
private:
    static const int MAX_FLIGHTS = 10;
    Flight* flights[MAX_FLIGHTS];
    int numFlights;
    Flight* bookedFlights[MAX_FLIGHTS];
    int numBookedFlights;
    int totalFare;

    TotalBill totalBill;
    CustomerInvoice info;

public:
    AirlineReservationSystem() : numFlights(0), numBookedFlights(0), totalFare(0) {
        flights[numFlights++] = new Airplane("PK101", "Karachi", 5000);
        flights[numFlights++] = new Airplane("PK102", "Lahore", 6000);
        flights[numFlights++] = new Airplane("PK103", "Islamabad", 7000);
        flights[numFlights++] = new Airplane("PK104", "Quetta", 8000);
        flights[numFlights++] = new Airplane("PK105", "Peshawar", 9000);
        flights[numFlights++] = new Airplane("PK106", "Faisalabad", 10000);
        flights[numFlights++] = new Airplane("PK107", "Multan", 11000);
        flights[numFlights++] = new Airplane("PK108", "Sialkot", 12000);
        flights[numFlights++] = new Airplane("PK109", "Gilgit", 13000);
        flights[numFlights++] = new Airplane("PK110", "Skardu", 14000);
    }

    void displayAvailableFlights() const {
        system("CLS");
        cout << "                                   =================================================\n";
        cout << "                                   ||            AVAILABLE FLIGHTS FOR BOOKING    ||\n";
        cout << "                                   =================================================\n";
        for (int i = 0; i < numFlights; ++i) {
            flights[i]->display(i + 1);
        }
        cout << endl;
    }

    void bookFlight() {
        int choice;
        cout << "\nEnter the flight number to book: ";
        cin >> choice;

        while (cin.fail() || choice < 1 || choice > numFlights) {
            cin.clear(); // Clear error flags
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear input buffer
            cout << "Invalid input. Please enter a valid flight number: ";
            cin >> choice;
        }

        Flight* flight = flights[choice - 1];

        bool isBooked = false;
        for (int i = 0; i < numBookedFlights; ++i) {
            if (bookedFlights[i] == flight) {
                isBooked = true;
                break;
            }
        }

        if (isBooked) {
            cout << "Sorry, the flight " << flight->getFlightNumber() << " is already booked. Choose another flight.\n\n";
        } else {
            int ticketCount;
            cout << "Enter the number of tickets to book: ";
            cin >> ticketCount;

            while (cin.fail() || ticketCount <= 0) {
                cin.clear(); // Clear error flags
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear input buffer
                cout << "Invalid input. Please enter a valid number of tickets: ";
                cin >> ticketCount;
            }

            int fare = ticketCount * flight->getFarePerTicket();
            totalFare += fare;
            totalBill.addFare(fare);

            bookedFlights[numBookedFlights++] = flight;
            char customerName[20];
            string cnic, number;
            cout << "\nEnter your name: ";
            cin.ignore();
            cin.getline(customerName, 20);
            cout << "Enter your Contact Number: ";
            cin >> number;
            cout << "Enter your CNIC Number: ";
            cin >> cnic;
            system("CLS");
            CustomerInvoice invoice(customerName, flight, choice, ticketCount, fare, number, cnic);
            invoice.display();
        }
    }

    void cancelBooking() {
        int choice;
        cout << "                                     =================================================\n";
        cout << "                                     ||             CANCEL A BOOKED FLIGHT         ||\n";
        cout << "                                     =================================================\n";
        cout << "Enter the flight number to cancel: ";
        cin >> choice;

        while (cin.fail() || choice < 1 || choice > numBookedFlights) {
            cin.clear(); // Clear error flags
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear input buffer
            cout << "Invalid input. Please enter a valid flight number to cancel: ";
            cin >> choice;
        }

        Flight* flight = bookedFlights[choice - 1];

        flights[numFlights] = flight;
        numFlights++;

        for (int i = choice - 1; i < numBookedFlights - 1; ++i) {
            bookedFlights[i] = bookedFlights[i + 1];
        }

        numBookedFlights--;

        cout << "You have canceled the booking for flight " << flight->getFlightNumber() << ". Thank you!\n";
    }

    void displayBookedFlights() const {
        system("CLS");
        if (numBookedFlights == 0) {
            cout << "                                =================================================\n";
            cout << "                                ||            NO FLIGHT BOOKED CURRENTLY       ||\n";
            cout << "                                =================================================\n";
        } else {
            cout << "                                =================================================\n";
            cout << "                                ||                BOOKED FLIGHTS               ||\n";
            cout << "                                =================================================\n";

            for (int i = 0; i < numBookedFlights; ++i) {
                bookedFlights[i]->display(i + 1);
            }
            cout << endl;
        }
    }

    void displayTotalBill() const {
        totalBill.displayTotal();
    }

    void displayRecord() {
        system("CLS");
        cout << "                                 =====================================================\n";
        cout << "                                 ||                  CUSTOMER RECORD                ||" << endl;
        cout << "                                 =====================================================\n";
        info.ReadFile();
    }
};

int main() {
    string username = "user123";
    string password = "123pass";
    string user;
    string pass;
    cout << "                                  =================================================\n";
    cout << "                                  ||            WELCOME TO THE LOGIN             ||\n";
    cout << "                                  =================================================\n";

    do {
        cout << "Enter Your username: ";
        cin >> user;
        cout << "Enter password: ";
        cin >> pass;
        if (pass != password || user != username) {
            cout << "\nINCORRECT PASSWORD OR USER NAME. PLEASE TRY AGAIN.\n";
        }
    } while (pass != password || user != username);

    AirlineReservationSystem reservationSystem;
    int choice;

    do {
        cout << "                                  =================================================\n";
        cout << "                                  ||            AIRLINE RESERVATION SYSTEM MENU   ||\n";
        cout << "                                  =================================================\n";
        cout << "1. Display available flights\n";
        cout << "2. Book a flight\n";
        cout << "3. Cancel a booking\n";
        cout << "4. Display booked flights\n";
        cout << "5. Display total bill\n";
        cout << "6. Display Customer Record\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        while (cin.fail() || choice < 1 || choice > 7) {
            cin.clear(); // Clear error flags
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear input buffer
            cout << "Invalid input. Please enter a number from 1 to 7: ";
            cin >> choice;
        }

        switch (choice) {
            case 1:
                cout << "\nDISPLAY AVAILABLE FLIGHTS\n";
                reservationSystem.displayAvailableFlights();
                break;
            case 2:
                reservationSystem.bookFlight();
                break;
            case 3:
                reservationSystem.cancelBooking();
                break;
            case 4:
                reservationSystem.displayBookedFlights();
                break;
            case 5:
                system("CLS");
                reservationSystem.displayTotalBill();
                break;
            case 6:
                reservationSystem.displayRecord();
                break;
            case 7:
                cout << "\nTHANK YOU FOR USING THE AIRLINE RESERVATION SYSTEM!\n";
                break;
            default:
                cout << "\nINVALID CHOICE. PLEASE TRY AGAIN.\n";
                break;
        }
    } while (choice != 7);

    return 0;
}

